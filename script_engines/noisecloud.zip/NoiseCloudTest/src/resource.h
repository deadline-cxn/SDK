//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NoiseCloudTest.rc
//
#define IDR_MENU1                       101
#define IDD_DIALOG1                     102
#define IDD_DIALOG2                     103
#define IDM_FILE_EXIT                   40001
#define IDM_DEVICE_DEVICE0              43000
#define IDM_MODE_WINDOWED               44000
#define IDM_MODE_FULL0                  44001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
