========================================================================
       Game
========================================================================

A non-playable game.
It's an experiment with a virtual machine and a scripting langauge.

To run the game, you probably need to edit the env.cfg file and
correct the path to the graphics directory.

To exit, press the Escape key.

regards
Bjarke Viksoe
bjarke@viksoe.dk

