//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by assimp_view.rc
//
#define IDC_MYICON                      2
#define IDD_ASSIMP_VIEW_DIALOG          102
#define IDD_ABOUTBOX                    103
#define IDI_ASSIMP_VIEW                 107


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        159
#define _APS_NEXT_COMMAND_VALUE         32831
#define _APS_NEXT_CONTROL_VALUE         1052
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
