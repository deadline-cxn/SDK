/***************************************************************************/
/*                                                                         */
/* File: dxdraw.cpp                                                        */
/* Author: bkenwright@screentoys.net                                       */
/* Date: 10-11-2002                                                        */
/*                                                                         */
/***************************************************************************/

LPDIRECT3D8 g_pD3D = NULL;
LPDIRECT3DDEVICE8 g_pD3DDevice = NULL;

/***************************************************************************/
/*                                                                         */
/* init, de_init, and set_camera are simple directX setup functions.       */
/*                                                                         */
/***************************************************************************/
void init(HWND hWnd)
{
    //First of all, create the main D3D object. If it is created successfully we 
    //should get a pointer to an IDirect3D8 interface.
    g_pD3D = Direct3DCreate8(D3D_SDK_VERSION);
    //Get the current display mode
    D3DDISPLAYMODE d3ddm;
    g_pD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &d3ddm);
    //Create a structure to hold the settings for our device
    D3DPRESENT_PARAMETERS d3dpp; 
    ZeroMemory(&d3dpp, sizeof(d3dpp));
    //Fill the structure. 
    //We want our program to be windowed, and set the back buffer to a format
    //that matches our current display mode
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = d3ddm.Format;
    //For depth buffering (e.g.) the z-buffer
    d3dpp.BackBufferCount=1;
    d3dpp.AutoDepthStencilFormat = D3DFMT_D16;
    d3dpp.EnableAutoDepthStencil = TRUE;
    //Create a Direct3D device
    g_pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd, D3DCREATE_SOFTWARE_VERTEXPROCESSING, &d3dpp, &g_pD3DDevice);
    //Turn off lighting becuase we are specifying that our vertices have colour
    g_pD3DDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
    //Turn on z-buffering
    g_pD3DDevice->SetRenderState(D3DRS_ZENABLE, D3DZB_TRUE);

	//Turn on back face culling. This is becuase we want to hide the back of our polygons
	g_pD3DDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
}

void de_init()
{
	g_pD3DDevice->Release();
    g_pD3DDevice = NULL;
    g_pD3D->Release();
    g_pD3D = NULL;
}
void set_camera()
{
    // [1] D3DTS_VIEW
    D3DXMATRIX v;
    g_pD3DDevice->SetTransform(D3DTS_VIEW, D3DXMatrixLookAtLH(&v, &D3DXVECTOR3(0,0,-100), 
                                                                  &D3DXVECTOR3(0,0,0), 
                                                                  &D3DXVECTOR3(0,1,0)));  
    // [2] D3DTS_PROJECTION
    D3DXMATRIX p;
    g_pD3DDevice->SetTransform( D3DTS_PROJECTION, D3DXMatrixPerspectiveFovLH( &p,  D3DX_PI/4,  1.0f,
                                                                                                 1.0f,200.0f));
};

struct my_vertex
{
      FLOAT x, y, z;  // D3DFVF_XYZ
      DWORD colour;   // D3DFVF_DIFFUSE
};

/***************************************************************************/
/*                                                                         */
/* This function is called repeatedly from main.cpp in windows code, as    */
/* it allows us to constandly display the model when windows is idle.      */
/*                                                                         */
/***************************************************************************/

void Render(stModelData* m)
{
	if(!g_pD3DDevice)return;

	// All we do here is set up where where looking at...eg. the camera pos.
	set_camera();

	// Set a world matrix so our md2 model rotates around.
	static float angle = 0.0f;
    angle += 0.0001f;
	//~~~*~~~~ Create a matrix
	D3DXMATRIX mx;
    //~~~*~~~~ Do somthing to our empty matrix.
    D3DXMatrixRotationY(&mx, angle ); // angle in radians...eg. 1 degree = PI/180
    //~~~*~~~~ Use the matrix! No use having a matrix if we don't use it!
    g_pD3DDevice->SetTransform(D3DTS_WORLD, &mx);


	// Create our directX buffer which will be used to hold or model data.
	UINT my_vertex_description = (D3DFVF_XYZ | D3DFVF_DIFFUSE);
	IDirect3DVertexBuffer8 * DX_vb;
	g_pD3DDevice->CreateVertexBuffer( m->numFaces * 3 * sizeof(my_vertex), 0, my_vertex_description, D3DPOOL_MANAGED, &DX_vb );

	// Copy our array which is in computer memory over to the directX memory.. using that pointer we
    // just created etc.
    unsigned char *temp_pointer_vb;
    my_vertex* tt = new my_vertex[m->numFaces * 3];

	for(int i=0; i< (m->numFaces); i++)
	{
		int index = m->pF[i].vertexIndex[0];
		tt[i*3].x = m->pV[ index ].x;
		tt[i*3].y = m->pV[ index ].y;
		tt[i*3].z = m->pV[ index ].z;
		tt[i*3].colour = 0xff00ffff;

		index = m->pF[i].vertexIndex[1];
		tt[i*3+1].x = m->pV[ index ].x;
		tt[i*3+1].y = m->pV[ index ].y;
		tt[i*3+1].z = m->pV[ index ].z;
		tt[i*3+1].colour = 0xff00ffff;
		
		index = m->pF[i].vertexIndex[2];
		tt[i*3+2].x = m->pV[ index ].x;
		tt[i*3+2].y = m->pV[ index ].y;
		tt[i*3+2].z = m->pV[ index ].z;
		tt[i*3+2].colour = 0xff00ffff;
	}
	
    DX_vb->Lock(0,0, &temp_pointer_vb, 0);
	memcpy(temp_pointer_vb, tt, m->numFaces * 3 * sizeof(my_vertex) );
    DX_vb->Unlock();
	delete[] tt;
    // Okay at this point... our graphics card has our vertices stored in it... we've just copied
    // them over :) Some stuff to setup or graphics card!
    //Turn off lighting becuase we are specifying that our vertices have colour
    g_pD3DDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
    g_pD3DDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
	g_pD3DDevice->SetTextureStageState(0,D3DTSS_COLORARG1, D3DTA_DIFFUSE);

	// Clear the back buffer to a blue color
	g_pD3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0,0,255), 1.0f, 0 );
	// Draw our triangle.
	g_pD3DDevice->SetStreamSource(0, DX_vb, sizeof(my_vertex));
	g_pD3DDevice->SetVertexShader(my_vertex_description);
	g_pD3DDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, m->numFaces);
	// After rendering the scene we display it.
	g_pD3DDevice->Present( NULL, NULL, NULL, NULL );
	
	// As where calling the functino over and over again.. we'd be constantly creating new memory
	// without releasing the old if not for this line!
	DX_vb->Release();
}




