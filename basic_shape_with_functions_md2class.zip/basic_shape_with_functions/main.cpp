/***************************************************************************/
/*                                                                         */
/* File: main.cpp                                                          */
/* Author: bkenwright@screentoys.net                                       */
/* Date: 10-11-2002                                                        */
/*                                                                         */
/***************************************************************************/
// If you want to compile from the dos prompted for visual studio use this:
// else ignore.
//type:
//      cl @RESP main.cpp
//      { inside file RESP contains the text:
//         /I "C:\Program Files\Microsoft Visual Studio .NET\Vc7\PlatformSDK\Include\prerelease"
//         /link /LIBPATH:"C:\PROGRA~1\MICROS~1.NET\Vc7\PLATFO~1\lib\PREREL~1\"
//      }


// These few lines are compiler directives that include the windows librarys
// during linking.  You could instead inside visual studio goto Project->
// settings" menu and under the "Link" tab add the necessary librarys instead.
#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "Advapi32.lib")
#pragma comment(lib, "Winmm.lib")

#include <windows.h>
#include <stdio.h>

#define ULONG_PTR unsigned long

#pragma comment(lib, "D3d8.lib") //directX 8
#pragma comment(lib, "D3dx8.lib")
#include <d3dx8.h>
//main.cpp
/***************************************************************************/
/*                                                                         */
/* These three structures will hold all our data from the .md2 model...    */
/* its only responsible for extracting it.. its not got the texture data   */
/* I'll add that in later... this shows a principle where you could create */
/* a set of structures where you read in the data into them.               */
/*                                                                         */
/***************************************************************************/

struct stArrayVerts
{
	float x, y, z;
};
struct stArrayFaces
{
	short vertexIndex[3];
};

struct stModelData
{
	int numVerts;
	int numFaces;
	stArrayVerts* pV;
	stArrayFaces* pF;
};
stModelData m; // Our global 3D model data will be in "m".

WNDCLASS a; HWND hwnd; MSG c;
long _stdcall zzz (HWND, UINT, WPARAM, LPARAM);


#include "md2.cpp"      // All the md2 loading stuff is in here!
#include "dxdraw.cpp"   // All the directX3D draw code is in here.!


void gameloop()
{
	Render(&m);  // This is called repeatedly to render our model data to screen.
}


int _stdcall WinMain(HINSTANCE i, HINSTANCE j, char *k, int l)
{
	a.lpszClassName="a1";
	a.hInstance = i;
	a.lpfnWndProc = zzz;
	a.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	RegisterClass(&a);
	hwnd=CreateWindow("a1", "time client", WS_OVERLAPPEDWINDOW, 30,30,300,300,NULL,NULL,i,NULL);

	init(hwnd);						// -1- Init DirectX.
	ShowWindow(hwnd,1);				// -2- Create our window.
	ReadMd2File(&m, "pac3D.md2");	// -3- Load our md2 file.
	while(1)
	{
		
		if (PeekMessage(&c, NULL, 0, 0, PM_NOREMOVE))
		{
			if(!GetMessage(&c, 0,0,0))
				break;
			DispatchMessage(&c);
		}
		else
			gameloop();            // -4- Display our md2 file data we loaded earlier.
	}
	return 1;
}

long _stdcall zzz (HWND w, UINT x, WPARAM y, LPARAM z)
{
	if (x == WM_DESTROY)
	{
		de_init();                 // -5- Destroy DirectX stuff.
		delete[] m.pV;			   // -6- Tidy up any memory allocation for our 3D model.
		delete[] m.pF;
		PostQuitMessage(0);
	}
	return DefWindowProc(w,x,y,z);
}

