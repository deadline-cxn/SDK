/***************************************************************************/
/*                                                                         */
/* File: md2.cpp                                                           */
/* Author: bkenwright@screentoys.net                                       */
/* Date: 10-11-2002                                                        */
/*                                                                         */
/***************************************************************************/

struct stMd2Header
{
	int magic;			// The magic number used to identify the file.
	int version;		// The file version number (must be 8).
	int skinWidth;		// The width in pixels of our image.
	int skinHeight;		// The height in pixels of our image.
	int frameSize;		// The size in bytes the frames are.
	int numSkins;		// The number of skins associated with the model.
	int numVertices;	// The number of vertices.
	int numTexCoords;	// The number of texture coordinates.
	int numTriangles;	// The number of faces (polygons).
	int numGlCommands;	// The number of gl commands.
	int numFrames;		// The number of animated frames.
	int offsetSkins;	// The offset in the file for the skin data.
	int offsetTexCoords;// The offset in the file for the texture data.
	int offsetTriangles;// The offset in the file for the face data.
	int offsetFrames;	// The offset in the file for the frames data.
	int offsetGlCommands;// The offset in the file for the gl commands data.
	int offsetEnd;		// The end of the file offset.
};
stMd2Header Md2Header;

// Some structures to hold or read in data in.
struct stSkins
{
	char skinName[64];
};

struct stTexCoords
{
	short u, v;
};

struct stVertices
{
	float vertex[3];
	float normal[3];
};

struct stTriangles
{
	short vertexIndex[3];
	short texIndex[3];
};

struct stVerts
{
	byte vertex[3]; // an index reference into the location of our vertexs
	byte lightNormalIndex; // in index into which tex coords to use.
};
struct stFrames
{
	float scale[3];
	float translate[3];
	char strFrameName[16];
	stVertices* pVerts;
};


void ReadMd2File(stModelData* m, char* szFileName)
{
	FILE *f = fopen(szFileName, "rb");
	fread(&Md2Header, 1, sizeof(Md2Header), f);

	// Allocate memory for our data so we can read it in.
	stSkins* pSkins		= new stSkins[ Md2Header.numSkins ];
	stTexCoords* pTexCoords = new stTexCoords[ Md2Header.numTexCoords ];
	stTriangles* pTriangles = new stTriangles[ Md2Header.numTriangles ];
	stFrames* pFrames = new stFrames[ Md2Header.numFrames ];

	// -1- Seek to the start of our skins name data and read it in.
	fseek(f, Md2Header.offsetSkins, SEEK_SET);
	fread(pSkins, sizeof(stSkins), Md2Header.numSkins, f);

	// -2- Seek to the start of our Texture Coord data and read it in.
	fseek(f, Md2Header.offsetTexCoords, SEEK_SET);
	fread(pTexCoords, sizeof(stTexCoords), Md2Header.numTexCoords, f);

	// -3- Seek to the start of the Triangle(e.g. Faces) data and read that in.
	fseek(f, Md2Header.offsetTriangles, SEEK_SET);
	fread(pTriangles, sizeof(stTriangles), Md2Header.numTriangles, f);

	// -4- Finally lets read in "one" of the frames, the first one.!
	
	struct stAliasFrame
	{
		float scale[3];
		float translate[3];
		char name[16];
		stVerts aliasVerts[1];
	};
	
	unsigned char largebuffer[10000];
	stAliasFrame* pTempFrame = (stAliasFrame*) largebuffer;

	fseek(f, Md2Header.offsetFrames, SEEK_SET);
	fread(pTempFrame, 1, Md2Header.frameSize, f); // We have read in all the frame data here (into a temporyary!!..eeEKK)..

	pFrames[0].pVerts = new stVertices[ Md2Header.numVertices ];
	
	// CONVERSION!  A few things before we can use our read in values,
	// for some reason the Z and Y need to be swapped, as Z is facing up
	// and Y is facing into the screen.
	// Also our texture coordinates values are between 0 and 256, we just
	// divide them all by 256 which makes them between 0 and 1.

	// Swap Z<->Y
	
	for(int i=0; i< Md2Header.numVertices; i++)
	{
		pFrames[0].pVerts[i].vertex[0] = pTempFrame->aliasVerts[i].vertex[0] * pTempFrame->scale[0] + pTempFrame->translate[0]; // x
		pFrames[0].pVerts[i].vertex[1] = pTempFrame->aliasVerts[i].vertex[2] * pTempFrame->scale[2] + pTempFrame->translate[2]; // y
		pFrames[0].pVerts[i].vertex[2] = -1 * (pTempFrame->aliasVerts[i].vertex[1] * pTempFrame->scale[1] + pTempFrame->translate[1]); // z
	}

	// Scale Textures.
	for (int j=0; j< Md2Header.numTexCoords; j++)
	{
		pTexCoords[j].u = pTexCoords[j].u / float(Md2Header.skinWidth);
		pTexCoords[j].v = pTexCoords[j].v / float(Md2Header.skinHeight);
	}

	// Now --Here-- is where we have all our data...if we wanted to could
	// convert of draw it here or something... but since we only wanted
	// to see how its extracted, we just clean up after ourselfs and exit.

   
	m->numVerts = Md2Header.numVertices;
	m->pV = new stArrayVerts[ m->numVerts ];

	for(int ii=0; ii< m->numVerts; ii++)
	{
		m->pV[ii].x = pFrames[0].pVerts[ii].vertex[0];
		m->pV[ii].y = pFrames[0].pVerts[ii].vertex[1];
		m->pV[ii].z = pFrames[0].pVerts[ii].vertex[2];
	}

	
	m->numFaces = Md2Header.numTriangles;
	m->pF = new stArrayFaces[ m->numFaces ];
	for(int jj=0; jj< m->numFaces; jj++)
	{
		m->pF[jj].vertexIndex[0] = pTriangles[jj].vertexIndex[0];
		m->pF[jj].vertexIndex[1] = pTriangles[jj].vertexIndex[1];
		m->pF[jj].vertexIndex[2] = pTriangles[jj].vertexIndex[2];
	}

	// Tidy up before exiting.
	delete[] pFrames[0].pVerts;
	delete[] pSkins;
	delete[] pTexCoords;
	delete[] pTriangles;
	delete[] pFrames;
	fclose(f);
}
