#!/bin/sh

cd ../../../tools/fsbanklib
./example
cp *.fsb ../../fmoddesignerapi/examples/media
