libmng 1.0.10
-------------

Added provisional ANG and anIM support, and made some minor bugfixes.

libmng 1.0.9
------------

A number of optimizations in the chunk handling and reader/writer code.
This saves over 20KB on binary footprint!

Also several bugfixes and a couple of patches bring it another step
closer to perfection.... :-)

See CHANGELOG for details.


Y.T.

Gerard


For more information please visit:

The official libmng web-site:
  http://www.libmng.com/

Libmng's community on SourceForge:
  https://sourceforge.net/project/?group_id=5635

The official MNG homepage:
  http://www.libpng.org/pub/mng/

The official PNG homepage:
  http://www.libpng.org/pub/png/

