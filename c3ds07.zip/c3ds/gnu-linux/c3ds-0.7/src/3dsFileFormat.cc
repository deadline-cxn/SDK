//
// File: 3dsFileFormat.h
// Created by: <Andrea Ingegneri>
//

#include "3dsFileFormat.h"
