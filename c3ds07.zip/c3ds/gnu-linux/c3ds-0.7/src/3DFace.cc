//
// File: 3DFace.h
// Created by: <Andrea Ingegneri>
//

#include "3DFace.h"

C3DFace::C3DFace()
{

}
