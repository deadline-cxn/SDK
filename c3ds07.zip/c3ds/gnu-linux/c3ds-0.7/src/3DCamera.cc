//
// File: 3DCamera.h
// Created by: <Andrea Ingegneri>
//

#include "3DCamera.h"

C3DCamera::C3DCamera()
{

}
